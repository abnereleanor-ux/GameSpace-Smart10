package id.smart10.gamespace;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.*;
import android.view.Gravity;
import android.widget.*;
import java.io.*;

public class TriggerActivity extends Activity {
    static final int PICK=11, CAPTURE=12;
    ImageView preview; TextView status; Uri selected;
    int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
    GradientDrawable bg(int c){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(16));return d;}
    TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(-1);b.setBackground(bg(Color.rgb(245,55,78)));return b;}
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(12,12,17));getWindow().setNavigationBarColor(Color.rgb(12,12,17));
        LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(18),dp(24),dp(18),dp(20));root.setBackgroundColor(Color.rgb(12,12,17));
        TextView title=label("AI TRIGGER",26,-1);title.setTypeface(null,1);root.addView(title);
        TextView sub=label("LOCAL IMAGE MATCHING",11,Color.rgb(255,75,95));sub.setPadding(0,dp(5),0,dp(18));root.addView(sub);
        TextView help=label("1 · PILIH GAMBAR PEMICU",14,-1);help.setTypeface(null,1);root.addView(help);
        preview=new ImageView(this);preview.setBackground(bg(Color.rgb(29,30,39)));preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(190));pp.topMargin=dp(12);pp.bottomMargin=dp(12);root.addView(preview,pp);
        Button choose=btn("PILIH GAMBAR DARI GALERI");root.addView(choose);choose.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK);});
        TextView note=label("Pilih gambar kecil yang jelas dan mudah dikenali. Pemantauan layar memerlukan izin rekam layar Android.",12,Color.LTGRAY);note.setPadding(0,dp(14),0,dp(14));root.addView(note);
        Button start=btn("2 · MULAI PEMANTAUAN");root.addView(start);start.setOnClickListener(v->startWatch());
        Button stop=btn("HENTIKAN PEMANTAUAN");stop.setBackground(bg(Color.rgb(65,65,75)));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(8);root.addView(stop,sp);
        stop.setOnClickListener(v->{stopService(new Intent(this,ImageWatchService.class));status.setText("Pemantauan dihentikan.");});
        status=label("Status: belum aktif",12,Color.rgb(180,185,195));status.setPadding(0,dp(16),0,0);root.addView(status);
        TextView disclaimer=label("Catatan: deteksi visual bersifat sederhana dan dapat keliru. Aplikasi hanya memberi notifikasi/getaran; tidak menyentuh atau mengendalikan game.",11,Color.rgb(160,165,175));disclaimer.setPadding(0,dp(18),0,0);root.addView(disclaimer);
        setContentView(root);
    }
    void startWatch(){
        if(selected==null){Toast.makeText(this,"Pilih gambar pemicu terlebih dahulu.",Toast.LENGTH_SHORT).show();return;}
        try{
            Bitmap bm=BitmapFactory.decodeStream(getContentResolver().openInputStream(selected));
            if(bm==null)throw new Exception("Gambar tidak terbaca");
            File f=new File(getFilesDir(),"trigger_ref.png");FileOutputStream out=new FileOutputStream(f);bm.compress(Bitmap.CompressFormat.PNG,100,out);out.close();bm.recycle();
            MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            startActivityForResult(m.createScreenCaptureIntent(),CAPTURE);
        }catch(Exception e){Toast.makeText(this,"Gagal membaca gambar: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);
        if(req==PICK&&res==RESULT_OK&&data!=null){selected=data.getData();try{getContentResolver().takePersistableUriPermission(selected,Intent.FLAG_GRANT_READ_URI_PERMISSION);preview.setImageURI(selected);}catch(Exception e){preview.setImageURI(selected);} }
        if(req==CAPTURE&&res==RESULT_OK&&data!=null){Intent s=new Intent(this,ImageWatchService.class);s.putExtra("resultCode",res);s.putExtra("data",data);if(Build.VERSION.SDK_INT>=26)startForegroundService(s);else startService(s);status.setText("Status: pemantauan aktif. Izin rekam layar diberikan.");}
    }
}
