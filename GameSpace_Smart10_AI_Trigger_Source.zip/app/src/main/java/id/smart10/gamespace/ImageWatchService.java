package id.smart10.gamespace;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import java.io.*;

public class ImageWatchService extends Service {
    Handler handler; MediaProjection projection; VirtualDisplay display; ImageReader reader;
    Bitmap template; long lastCheck=0; boolean wasMatch=false; int stable=0; int width,height,density;
    final Runnable scan=new Runnable(){public void run(){try{checkFrame();}catch(Exception ignored){} if(projection!=null)handler.postDelayed(this,1500);}};
    @Override public void onCreate(){super.onCreate();handler= new Handler(Looper.getMainLooper());}
    @Override public int onStartCommand(Intent intent,int flags,int id){
        createChannel();startForeground(41,notification("Menyiapkan pemantauan gambar…"));
        try{
            File f=new File(getFilesDir(),"trigger_ref.png");template=BitmapFactory.decodeFile(f.getAbsolutePath());
            if(template==null){stopSelf();return START_NOT_STICKY;}
            MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection=m.getMediaProjection(intent.getIntExtra("resultCode",0),(Intent)intent.getParcelableExtra("data"));
            if(projection==null){stopSelf();return START_NOT_STICKY;}
            projection.registerCallback(new MediaProjection.Callback(){@Override public void onStop(){stopSelf();}},handler);
            width=getResources().getDisplayMetrics().widthPixels;height=getResources().getDisplayMetrics().heightPixels;density=getResources().getDisplayMetrics().densityDpi;
            reader=ImageReader.newInstance(width,height,android.graphics.PixelFormat.RGBA_8888,2);
            display=projection.createVirtualDisplay("GameSpaceImageWatch",width,height,density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
            handler.post(scan);
        }catch(Exception e){stopSelf();}
        return START_NOT_STICKY;
    }
    void checkFrame(){
        if(reader==null)return;Image im=reader.acquireLatestImage();if(im==null)return;
        Bitmap frame=null;
        try{
            Image.Plane plane=im.getPlanes()[0];ByteBufferWrap wrap=new ByteBufferWrap(plane.getBuffer());
            int row=plane.getRowStride(),pixel=plane.getPixelStride();
            Bitmap padded=Bitmap.createBitmap(row/pixel,height,Bitmap.Config.ARGB_8888);
            padded.copyPixelsFromBuffer(wrap.buffer);
            frame=Bitmap.createBitmap(padded,0,0,width,height);padded.recycle();
            boolean match=find(frame);
            stable=match?stable+1:0;
            if(stable>=2&&!wasMatch){notifyMatch();wasMatch=true;}
            if(!match)wasMatch=false;
        }catch(Exception ignored){}finally{if(frame!=null)frame.recycle();im.close();}
    }
    boolean find(Bitmap frame){
        int tw=16,th=16;Bitmap t=Bitmap.createScaledBitmap(template,tw,th,true);
        int[] target=new int[tw*th];t.getPixels(target,0,tw,0,0,tw,th);t.recycle();
        int stepX=Math.max(4,width/100),stepY=Math.max(4,height/160);
        int maxX=Math.max(1,width-tw),maxY=Math.max(1,height-th);
        for(int y=0;y<maxY;y+=stepY)for(int x=0;x<maxX;x+=stepX){
            long diff=0;int samples=0;
            for(int j=0;j<th;j+=2)for(int i=0;i<tw;i+=2){
                int a=frame.getPixel(x+i,y+j),b=target[j*tw+i];
                diff+=Math.abs(Color.red(a)-Color.red(b))+Math.abs(Color.green(a)-Color.green(b))+Math.abs(Color.blue(a)-Color.blue(b));samples+=3;
            }
            if(diff/(double)samples<24)return true;
        }return false;
    }
    void notifyMatch(){
        android.os.Vibrator vib=(android.os.Vibrator)getSystemService(VIBRATOR_SERVICE);
        if(Build.VERSION.SDK_INT>=26)vib.vibrate(VibrationEffect.createOneShot(180,VibrationEffect.DEFAULT_AMPLITUDE));
        else vib.vibrate(180);
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.notify(42,notification("Gambar pemicu terdeteksi"));
    }
    void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel("watch","AI Trigger",NotificationManager.IMPORTANCE_DEFAULT);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    Notification notification(String s){Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"watch"):new Notification.Builder(this);return b.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("GameSpace AI Trigger").setContentText(s).setOngoing(true).build();}
    @Override public void onDestroy(){handler.removeCallbacksAndMessages(null);if(display!=null)display.release();if(reader!=null)reader.close();if(projection!=null)projection.stop();if(template!=null)template.recycle();super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
    static class ByteBufferWrap{java.nio.ByteBuffer buffer;ByteBufferWrap(java.nio.ByteBuffer b){buffer=b;}}
}
