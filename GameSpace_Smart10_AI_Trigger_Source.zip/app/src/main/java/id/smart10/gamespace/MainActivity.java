package id.smart10.gamespace;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.os.Debug;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, gamesList;
    int red = Color.rgb(255,55,75);
    int white = Color.WHITE;
    int muted = Color.rgb(165,170,185);

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }

    GradientDrawable bg(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }

    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size);
        t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    void pad(View v, int l, int t, int r, int b) {
        v.setPadding(dp(l),dp(t),dp(r),dp(b));
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(12,12,17));
        getWindow().setNavigationBarColor(Color.rgb(12,12,17));
        getWindow().getDecorView().setSystemUiVisibility(0);
        build();
    }

    void build() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this); root.setOrientation(1);
        root.setBackgroundColor(Color.rgb(12,12,17)); pad(root,18,20,18,24);
        scroll.addView(root); setContentView(scroll);

        TextView brand = text("GAME SPACE", 13, red, true);
        root.addView(brand);
        TextView title = text("Your gaming\ncommand center", 29, white, true);
        title.setGravity(Gravity.CENTER_VERTICAL); pad(title,0,12,0,6); root.addView(title);
        TextView sub = text("SMART 10 EDITION  •  ANDROID 15", 11, muted, true);
        root.addView(sub);

        LinearLayout hero = new LinearLayout(this); hero.setOrientation(1);
        hero.setBackground(bg(Color.rgb(35,20,27),18,Color.rgb(105,38,52)));
        pad(hero,18,18,18,18);
        TextView h = text("GAMING MODE",12,red,true); hero.addView(h);
        TextView desc = text("Siapkan ponselmu sebelum bermain.",15,white,true);
        pad(desc,0,8,0,14); hero.addView(desc);
        Button refresh = button("REFRESH DAFTAR GAME");
        hero.addView(refresh);
        refresh.setOnClickListener(v -> loadGames());
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1,-2);
        hp.topMargin=dp(22); root.addView(hero,hp);
        Button ai = button("AI TRIGGER  ·  IMAGE DETECTION");
        LinearLayout.LayoutParams aip = new LinearLayout.LayoutParams(-1, dp(54));
        aip.topMargin = dp(12); root.addView(ai, aip);
        ai.setOnClickListener(v -> startActivity(new Intent(this, TriggerActivity.class)));

        TextView section = text("GAME LIBRARY",18,white,true);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1,-2);
        sp.topMargin=dp(25); sp.bottomMargin=dp(10); root.addView(section,sp);
        gamesList = new LinearLayout(this); gamesList.setOrientation(1); root.addView(gamesList);

        TextView info = text("TOOLS",18,white,true);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1,-2);
        ip.topMargin=dp(24); ip.bottomMargin=dp(10); root.addView(info,ip);
        addTool("RAM TERPAKAI", ramInfo());
        addTool("PERANGKAT", "Unisoc T7250 • Android 15");
        addTool("CATATAN", "Tutup aplikasi yang tidak diperlukan secara manual sebelum bermain.");
        TextView footer = text("GAME SPACE SMART 10  •  VERSION 1.0",10,muted,false);
        footer.setGravity(Gravity.CENTER); pad(footer,0,24,0,4); root.addView(footer);
        loadGames();
    }

    Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextSize(12);
        b.setTextColor(white); b.setAllCaps(false); b.setBackground(bg(red,12,0));
        return b;
    }

    void addTool(String name, String value) {
        LinearLayout card = new LinearLayout(this); card.setOrientation(1);
        card.setBackground(bg(Color.rgb(25,26,34),14,Color.rgb(48,49,60)));
        pad(card,15,12,15,12);
        TextView a=text(name,10,red,true); card.addView(a);
        TextView c=text(value,14,white,false); pad(c,0,5,0,0); card.addView(c);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
        p.bottomMargin=dp(9); root.addView(card,p);
    }

    String ramInfo() {
        android.app.ActivityManager am=(android.app.ActivityManager)getSystemService(ACTIVITY_SERVICE);
        android.app.ActivityManager.MemoryInfo mi=new android.app.ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        long used=(mi.totalMem-mi.availMem)/1024/1024;
        return used+" MB digunakan • "+(mi.totalMem/1024/1024)+" MB total";
    }

    void loadGames() {
        gamesList.removeAllViews();
        Intent intent=new Intent(Intent.ACTION_MAIN,null);
        intent.addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm=getPackageManager();
        List<ResolveInfo> apps=pm.queryIntentActivities(intent,0);
        Collections.sort(apps,(a,b)->a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString()));
        int count=0;
        for (ResolveInfo ri:apps) {
            String pkg=ri.activityInfo.packageName;
            if (pkg.equals(getPackageName())) continue;
            LinearLayout row=new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setBackground(bg(Color.rgb(25,26,34),14,Color.rgb(48,49,60)));
            pad(row,12,10,12,10);
            ImageView icon=new ImageView(this);
            try { icon.setImageDrawable(ri.loadIcon(pm)); } catch(Exception ignored) {}
            row.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(42)));
            TextView name=text(ri.loadLabel(pm).toString(),14,white,true);
            pad(name,12,0,6,0);
            row.addView(name,new LinearLayout.LayoutParams(0,-2,1));
            Button open=button("BUKA"); open.setTextSize(10);
            row.addView(open,new LinearLayout.LayoutParams(dp(76),dp(44)));
            open.setOnClickListener(v->{
                Intent launch=pm.getLaunchIntentForPackage(pkg);
                if(launch!=null) startActivity(launch);
                else Toast.makeText(this,"Aplikasi tidak bisa dibuka.",Toast.LENGTH_SHORT).show();
            });
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);
            p.bottomMargin=dp(9); gamesList.addView(row,p); count++;
        }
        if(count==0) {
            TextView empty=text("Belum ada aplikasi yang terdeteksi.",13,muted,false);
            pad(empty,8,14,8,14); gamesList.addView(empty);
        }
    }
}
