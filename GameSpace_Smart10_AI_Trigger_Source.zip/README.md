# GameSpace Smart 10

Aplikasi Android sederhana bergaya gaming dashboard untuk Infinix Smart 10 (X6725), Android 15.

## Fitur versi awal
- Tema gelap hitam-merah.
- Mendeteksi aplikasi yang memiliki launcher icon.
- Tombol untuk membuka aplikasi/game.
- Menampilkan ringkasan penggunaan RAM.
- Informasi chipset dan Android yang ditargetkan.

## Batasan
Aplikasi ini tidak mengubah clock CPU/GPU, tidak menjanjikan FPS lebih tinggi, tidak memodifikasi Free Fire, dan tidak mengakses fitur sistem tertutup milik XOS. Panel performa hanya menampilkan informasi dasar.

## Build APK lewat GitHub Actions
1. Buat repository GitHub baru.
2. Upload seluruh isi folder proyek ini.
3. Buka tab Actions dan jalankan workflow Android APK Build.
4. Setelah selesai, unduh artifact `GameSpace-Smart10-debug-apk`.
5. Ekstrak ZIP artifact, lalu pasang `app-debug.apk` di Infinix Smart 10.

Kebutuhan build: JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Android SDK Platform 35.

## AI Trigger (Image Detection)
- Pilih satu gambar referensi dari galeri.
- Beri izin rekam layar melalui dialog sistem Android.
- Aplikasi memeriksa frame layar secara lokal sekitar setiap 1,5 detik.
- Dua kecocokan berurutan memicu notifikasi dan getaran; harus hilang dulu sebelum dapat memicu lagi.
- Tidak mengirim screenshot ke internet dan tidak melakukan tap otomatis.
- Pencocokan versi awal sederhana; perubahan ukuran, animasi, transparansi, atau warna dapat membuat hasil tidak akurat.
